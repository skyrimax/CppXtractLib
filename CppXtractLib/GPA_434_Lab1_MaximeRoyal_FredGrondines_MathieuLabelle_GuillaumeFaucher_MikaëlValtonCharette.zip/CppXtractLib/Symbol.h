#ifndef SYMBOL_H
#define SYMBOL_H

// Tous les symboles manipul�s par l'automate doivent �tre de ce type.
using symbol_t = char;

#endif // SYMBOL_H