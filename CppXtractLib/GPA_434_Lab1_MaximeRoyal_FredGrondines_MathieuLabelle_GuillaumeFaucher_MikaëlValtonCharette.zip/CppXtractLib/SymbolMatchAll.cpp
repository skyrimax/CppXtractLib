#include "SymbolMatchAll.h"

// 1) Pas de constructeur � implanter.

// 2) Implantation de la fonction (purement virtuelle) compare()
bool SymbolMatchAll::compare(symbol_t symbol) const
{
	return true;
}