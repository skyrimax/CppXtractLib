#include "SymbolComparator.h"

// Cette classe purement virtuelle et son .cpp est vide

